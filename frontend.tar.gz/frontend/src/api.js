import axios from 'axios';

const api = axios.create({
    baseURL: 'http://localhost:8000',
});

export const getStats = async () => {
    const response = await api.get('/stats');
    return response.data;
};

export const getQueries = async (skip = 0, limit = 50, minDuration = null, queryType = null) => {
    const params = { skip, limit };
    if (minDuration) params.min_duration = minDuration;
    if (queryType) params.query_type = queryType;

    const response = await api.get('/queries', { params });
    return response.data;
};

export const triggerIngest = async () => {
    const response = await api.post('/ingest');
    return response.data;
};
