import React, { useEffect, useState } from 'react';
import { getQueries, getStats, triggerIngest } from './api';
import StatsCard from './components/StatsCard';
import QueryTable from './components/QueryTable';
import { Database, RefreshCw, Zap } from 'lucide-react';

function App() {
  const [stats, setStats] = useState(null);
  const [queries, setQueries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [ingesting, setIngesting] = useState(false);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [statsData, queriesData] = await Promise.all([
        getStats(),
        getQueries(0, 100) // fetch top 100 recent
      ]);
      setStats(statsData);
      setQueries(queriesData);
    } catch (err) {
      console.error("Failed to fetch data:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSync = async () => {
    try {
      setIngesting(true);
      await triggerIngest();
      // Poll or wait a bit, then refresh. 
      // For simple UX, we'll just wait 2s simulating background start, 
      // user can refresh manually or we can set interval.
      setTimeout(fetchData, 2000);
    } catch (err) {
      console.error("Ingest failed:", err);
    } finally {
      setIngesting(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="container">
      {/* Header */}
      <header style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '2rem',
        paddingBottom: '2rem',
        borderBottom: '1px solid var(--border)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{
            background: 'linear-gradient(135deg, var(--accent), #4f46e5)',
            padding: '12px',
            borderRadius: '12px',
            boxShadow: '0 0 20px var(--accent-glow)'
          }}>
            <Database size={32} color="white" />
          </div>
          <div>
            <h1>RDS Leap</h1>
            <div style={{ color: 'var(--text-secondary)' }}>Slow Query Intelligence</div>
          </div>
        </div>

        <button onClick={handleSync} disabled={ingesting}>
          <RefreshCw size={18} className={ingesting ? 'spin' : ''} style={ingesting ? { animation: 'spin 1s linear infinite' } : {}} />
          {ingesting ? 'Syncing...' : 'Sync Logs'}
        </button>
      </header>

      {/* Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
        gap: '1.5rem',
        marginBottom: '2rem'
      }}>
        <StatsCard
          title="Total Slow Queries"
          value={stats?.total_queries || 0}
          type="total"
          subtext="Captured in local DB"
        />
        <StatsCard
          title="Avg Duration"
          value={`${stats?.avg_duration || 0} ms`}
          type="avg"
          subtext="Average latency of captured queries"
        />
        <StatsCard
          title="Max Duration"
          value={`${stats?.max_duration || 0} ms`}
          type="max"
          subtext="Slowest query recorded"
        />
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-secondary)' }}>
          <Zap size={48} style={{ opacity: 0.2, marginBottom: '1rem' }} />
          <div>Loading Intelligence...</div>
        </div>
      ) : (
        <QueryTable queries={queries} maxDuration={stats?.max_duration || 1} />
      )}

      <style>{`
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

export default App;
