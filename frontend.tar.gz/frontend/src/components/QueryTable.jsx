import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Copy } from 'lucide-react';

const QueryTable = ({ queries, maxDuration }) => {
    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        // Could add toast here
    };

    const getTypeClass = (type) => {
        if (type === 'SELECT') return 'select';
        if (type === 'WRITE') return 'write';
        return 'other';
    };

    return (
        <div className="card glass">
            <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
                Recent Slow Queries
            </h3>
            <div style={{ overflowX: 'auto' }}>
                <table className="data-table">
                    <thead>
                        <tr>
                            <th style={{ width: '80px' }}>Type</th>
                            <th style={{ width: '120px' }}>DB</th>
                            <th style={{ width: '150px' }}>User</th>
                            <th style={{ width: '120px' }}>Duration (s)</th>
                            <th style={{ width: '150px' }}>When</th>
                            <th>Query</th>
                            <th style={{ width: '50px' }}></th>
                        </tr>
                    </thead>
                    <tbody>
                        {queries.map((q) => {
                            // Calculate percentage relative to max for the bar
                            const pct = maxDuration ? Math.min((q.duration_ms / maxDuration) * 100, 100) : 0;

                            return (
                                <tr key={q.id}>
                                    <td>
                                        <span className={`tag ${getTypeClass(q.query_type)}`}>{q.query_type}</span>
                                    </td>
                                    <td style={{ fontWeight: 500 }}>{q.db_name || '-'}</td>
                                    <td style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>{q.user_name || '-'}</td>
                                    <td>
                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                            <div className="duration-bar" style={{ width: '60px', background: 'rgba(255,255,255,0.05)' }}>
                                                <div className="duration-fill" style={{ width: `${pct}%`, background: q.duration_ms > 1000 ? 'var(--danger)' : 'var(--accent)' }}></div>
                                            </div>
                                            <span style={{ fontWeight: 600 }}>{(q.duration_ms / 1000).toFixed(3)}s</span>
                                        </div>
                                    </td>
                                    <td style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
                                        {formatDistanceToNow(new Date(q.timestamp), { addSuffix: true })}
                                    </td>
                                    <td>
                                        <div className="code-block" style={{ maxHeight: '60px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                            {q.query_text}
                                        </div>
                                    </td>
                                    <td>
                                        <button className="secondary" style={{ padding: '4px' }} onClick={() => copyToClipboard(q.query_text)} title="Copy Query">
                                            <Copy size={14} />
                                        </button>
                                    </td>
                                </tr>
                            );
                        })}
                        {queries.length === 0 && (
                            <tr>
                                <td colSpan="5" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>
                                    No queries found. Trigger ingestion/sync to fetch logs.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default QueryTable;
